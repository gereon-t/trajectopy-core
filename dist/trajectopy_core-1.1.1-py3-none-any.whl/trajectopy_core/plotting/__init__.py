import matplotlib.pyplot as plt

plt.rcParams["figure.max_open_warning"] = 50
